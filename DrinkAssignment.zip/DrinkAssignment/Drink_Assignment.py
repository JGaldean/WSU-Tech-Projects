class Drink:
    _valid_bases = {"water", "sbrite", "pokecola", "Mr. Salt", "hill fog", "leaf wine"}
    _valid_flavors = {"lemon", "cherry", "strawberry", "mint", "blueberry", "lime"}
    _size_costs = {
        "small" : 1.50,
        "medium" : 1.75,
        "large" : 2.05,
        "mega" : 2.50
    }

    def __init__(self, size):
        """ This creates a drink without a base or any flavors """
        self._base = None
        self._flavors = set()
        self._size = None
        self._cost = 0.0
        self.set_size(size)

    def get_base(self):
        """ This function will return the base of a drink """
        return self._base
    
    def get_flavors(self):
        """ This function will return a list of flavors in a drink """
        return list(self._flavors)
    
    def get_num_flavors(self):
        """ This function will return the number of flavors in a drink """
        return len(self._flavors)
    
    def get_size(self):
        return self._size
    
    def get_total(self):
        return self._cost
    
    def set_base(self, base):
        """ This will set the base of a drink, and make sure that it is a valid base """
        if base in self._valid_bases:
            self._base = base
        else:
            raise ValueError(f"Invalid Base: {base}. Please pick a base from {self._valid_bases}.")
        
    def add_flavor(self, flavor):
        """ This will add a flavor to the drink assuming that it is a valid option """
        if flavor in self._valid_flavors:
            if flavor not in self._flavors:
                self._flavors.add(flavor)
                self._cost += 0.15
        else:
            raise ValueError(f"Invalid Flavor: {flavor}. Please pick a flavor from {self._valid_flavors}.")
    
    def set_flavors(self, flavors):
        """ This will set the flavor of the drink and replace the existing flavors """
        if all(flavor in self._valid_flavors for flavor in flavors):
            new_flavors = set(flavors) - self.flavors
            self._cost += 0.15 * len(new_flavors)
            self._flavors = set(flavors)
        else:
            invalid_flavors = {flavor for flavor in flavors if flavor not in self._valid_flavors}
            raise ValueError(f"Invalid Flavor. Please pick a flavor from {self._valid_flavors}.")

    def set_size(self, size):
        size = size.lower()

        if size in self._size_costs:
            self._size = size
            self._cost = self._size_costs[size] + 0.15 * len(self._flavors)
        else:
            raise ValueError(f"Invalid Size. Please pick a different size : {list(self._size_costs.keys())}.")


class Order:
    _tax_rate = 0.0725

    def __init__(self):
        """ This creates and empty list of items"""
        self._items = []
    
    def get_items(self):
        """ This will return a list with all of the drinks in the order """
        return self._items
    
    def get_total(self):
        """ This will return the price of the drinks based of the number of drinks multiplied by the cost ($5) """
        return len(self._items)
    
    def get_num_items(self):
        return len(self._items)
    
    def get_total(self):
        return sum(drink.get_total() for drink in self._items)
    
    def get_tax(self):
        return self.get_total() * (1 + self._tax_rate)
    
    def get_receipt(self):
        """ This is the function that will actually create a receipt for the order """
        receipt_data = {
            "number_drinks" : self.get_num_items(),
            "drinks" : [],
            "subtotal" : round(self.get_total(), 2),
            "tax" : round(self.get_total() * self._tax_rate, 2),
            "grand_total" : round(self.get_tax(), 2)
        }

        for i, drink in enumerate(self._items):
            drink_data = {
                "Number_drinks" : i + 1,
                "base" : drink.get_base(),
                "size" : drink.get_size(),
                "flavors" : drink.get_flavors(),
                "total_cost" : round(drink.get_total(), 2)
            }
            receipt_data["drinks"].append(drink_data)
        return receipt_data
    
    def add_item(self, drink):
        """ This function will add a drink to the order """
        if isinstance(drink, Drink):
            self._items.append(drink)
        else:
            raise ValueError("You can only add drinks to this order!")
    
    def remove_item(self, index):
        """ And this function will remove a drink from the order """
        if 0 <= index < len(self._items):
            self._items.pop(index)
        else:
            raise IndexError("Invalid Request, You cannot remove this")
        
"""
I have decided on using unittest to test all of the getters and accessors in this project
In order to run it just go to this file in a terminal/cmd line and type 

"python -m unittest test_drink.py test_order.py"

"""